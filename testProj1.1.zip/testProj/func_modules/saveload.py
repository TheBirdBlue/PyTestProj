import time

def createOver(file, charName, charLvl, charExp, charMun, charAtk, charDef, charSpe):
    loadOrder = ['', 1, 0, 0, 1, 1, 1]
    name = input(' What is your name? ')
    loadOrder[0] = name
    with open(file, 'a+') as save:
        save.write(name)
        save.write('\n')

        # Overworld Info
        save.write(str(loadOrder[1]) + '\n')
        save.write(str(loadOrder[2]) + '\n')
        save.write(str(loadOrder[3]) + '\n')

        # Stat Info
        save.write(str(loadOrder[4]) + '\n')
        save.write(str(loadOrder[5]) + '\n')
        save.write(str(loadOrder[6]) + '\n')

        ''''# Set Returns
        level = loadOrder[1]
        exp = loadOrder[2]
        money = loadOrder[3]
        attack = loadOrder[4]
        defense = loadOrder[5]
        special = loadOrder[6]
        time.sleep(2)
        return name, charName, charLvl, charExp, charMun, charAtk, charDef, charSpe'''

    return loadOrder

def createStats(file):
    loadOrder = [0, 0, 0, 0, 0, 0]
    with open(file, 'a+') as save:

        # Set all as 0 on new save
        save.write(str(loadOrder[0]) + '\n')
        save.write(str(loadOrder[1]) + '\n')
        save.write(str(loadOrder[2]) + '\n')
        save.write(str(loadOrder[3]) + '\n')
        save.write(str(loadOrder[4]) + '\n')
        save.write(str(loadOrder[5]) + '\n')

        return file

def createResources(file):
    loadOrder = [0, 0, 0, 0, 0, 0, 0, 0]
    with open(file, 'a+') as save:

        # Set all as 0 on new save
        save.write(str(loadOrder[0]) + '\n')
        save.write(str(loadOrder[1]) + '\n')
        save.write(str(loadOrder[2]) + '\n')
        save.write(str(loadOrder[3]) + '\n')
        save.write(str(loadOrder[4]) + '\n')
        save.write(str(loadOrder[5]) + '\n')
        save.write(str(loadOrder[6]) + '\n')
        save.write(str(loadOrder[7]) + '\n')

        return file

def loadOver(file, name, level, exp, money, attack, defense, special):
    loadOrder = []
    with open(file, 'r') as save:
        for line in save:
            line = line.replace('\n', '')
            loadOrder.append(line)

        '''# Set Returns
        name = loadOrder[0]
        name.removesuffix('\n')
        level = loadOrder[1]
        exp = loadOrder[2]
        money = loadOrder[3]
        attack = loadOrder[4]
        defense = loadOrder[5]
        special = loadOrder[6]
        time.sleep(2)
        common.clear()
        return name, int(level), int(exp), int(money), int(attack), int(defense), int(special)'''

    return loadOrder

def saveOver(file, name, level, exp, money, attack, defense, special):
    saveOrder = [name, level, exp, money, attack, defense, special]
    with open(file, 'w') as save:
        for line in saveOrder:
            str(line).rstrip('\n')
            save.write(str(line))
            save.write('\n')

        time.sleep(1)
