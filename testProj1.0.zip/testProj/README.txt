Welcome to a Python project of no real name!

I want to explain how this 'game' works for anyone who dares wander into this mess.

To get started, run 'main.py' and let it take it from there.


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


You play a character of your own naming with the goal of getting stronger. How does that work? You have two big resources that help you. Exp and Mun.

Exp is your experience. You gain it by having successful hunts. It can be brought into the Level Up menu and used to increase your stats and your chances of a more successful hunt. The experience required to level up your skill is your current skill value plus 1. IE; you want to level up your 2 Str, you will need 3 Exp.

Mun is your money. It is used in the shop to increase your special. How does this work? Only the shop keeper knows. His prices are steep but special has the greatest advantage in hunting. It costs 25 Mun per level of special. IE; you want to upgrade your special from 1 to 2, it will cost you 25 Mun. From 2 to 3 will cost 50 Mun


HUNTING
-------
Hunting is your main source of income and experience. There is one big variable in hunting and that is the Rank fo the hunt. You can change the rank before and after any hunt. The higher the rank, the higher the reward but the harder it will be. There is NEVER a 100% chance that a hunt will succeed no matter how strong you are.

LEVEL UP
--------
Leveling Up is how you get more powerful. Your level only indicates how many times you have upgraded your stats, not how powerful you really are or a recommendation of what rank you should be at.

SHOP
----
Not so much items as much as a special way to upgrade your special stat. They take Muns here so you better have deep pockets. The shop keeper also likes to play games. You might be able to win some money back from him.

For selling resources, include the main option (3) along with the sub resource (1 through 3) with a dash inbetween. Ex; 3-1 to sell wood.

VISIT TOWN
--------
There is so much to do here that it could almost have it's own read me. The town is a progressional resource management that eventually pays out to the player and can be self sustaining. The player can build it up to begin with and with every hunt there is a chance that resources are gathered depending on the level of the resource collector. Resources can be used to upgrade buildings and to sell for money.

STATS
--------
It keeps track of all the incoming and outgoing numbers from expereince and money won from hunting and spent at the shop and leveling up. Might need a little more work but for now, it tracks just fine. Just make sure you save your game.

SAVE & QUIT
-----------
The most important one of the group! You MUST select this option when you go to quit to save your character stats. If you do not, they will not be written. And the save file is also located int he save folder. If you want to start over just delete it. If you want to be super powerful and give yourself amazing stats, go ahead! Have fun with it. The file writes as such;

LINE 1 > NAME
LINE 2 > LEVEL
LINE 3 > EXP
LINE 4 > MONEY
LINE 5 > ATTACK
LINE 6 > DEFENSE
LINE 7 > SPECIAL

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


This project was created to reenforce basic python skills and never intended for release outside of a small group. If you did manage to find this, then understand that the program is provided as is with no warranty or support. If you paid for it, you got ripped off. If you're selling it, you're ripping someone off.