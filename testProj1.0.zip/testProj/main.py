#!/usr/bin/python

import os
import sys

sys.path.insert(0, './func_modules')

import time
import hunt
import levelup
import shop
import town
import stats
import saveload
import common

# Import Folder
sys.path.insert(0, './func_modules')

run = True
fileLocationUser = 'save/saveOverview.txt'
fileLocationStats = 'save/saveStats.txt'
fileLocationResources = 'save/saveResources.txt'
list = ('Hunt', 'Level Up', 'Shop', 'Visit Town', 'Stats', 'Save & Quit')

def main():

    # Set Character values before loading
    charName = ''
    charLvl = 0
    charExp = 0
    charMun = 0
    charAtk = 0
    charDef = 0
    charSpe = 0

    # Load or create save files
    if os.path.exists(fileLocationUser) == False:
        workingOverview = saveload.createOver(fileLocationUser, charName, charLvl, charExp, charMun, charAtk, charDef, charSpe)
        saveload.createStats(fileLocationStats)
        saveload.createResources(fileLocationResources)
        common.clear()
    elif os.stat(fileLocationUser).st_size == 0:
        workingOverview = saveload.createOver(fileLocationUser, charName, charLvl, charExp, charMun, charAtk, charDef, charSpe)
        common.clear()
    else:
        workingOverview = saveload.loadOver(fileLocationUser, charName, charLvl, charExp, charMun, charAtk, charDef, charSpe)
        common.clear()

    # Change values to created and loaded values
    charName = workingOverview[0]
    charLvl = workingOverview[1]
    charExp = workingOverview[2]
    charMun = workingOverview[3]
    charAtk = workingOverview[4]
    charDef = workingOverview[5]
    charSpe = workingOverview[6]

    # Main running loop
    while run == True:

        # Change values to created and loaded values
        charName = workingOverview[0]
        charLvl = workingOverview[1]
        charExp = workingOverview[2]
        charMun = workingOverview[3]
        charAtk = workingOverview[4]
        charDef = workingOverview[5]
        charSpe = workingOverview[6]

        common.clear()
        workingOverview = [charName, charLvl, charExp, charMun, charAtk, charDef, charSpe]

        # GUI for Over Stats
        number = 1
        print(' Welcome ' + charName)
        print(' ╔════════════════════╡')
        #f'{value:,}'
        infoLine = ' ╟Lvl:{:>15} ╡\n ╟Exp:{:>15} ╡\n ╟Mun:{:>15} ╡'
        print(infoLine.format(charLvl, charExp, charMun))

        # GUI for Player Stats
        print(' ╠════════════════════╡')
        statHeader = ' ╠  ATK ╬  DEF ╬  SPE ╡'
        print(statHeader)
        statLine = ' ╠{:>5} ╬{:>5} ╬{:>5} ╡'
        print(statLine.format(charAtk, charDef, charSpe))

        # GUI for Choices and Actions
        print(' ╠═══╦════════════════╡')
        for choice in list:
            choiceLine = ' ╟(' + str(number) + ")╟ " + '{:<15}' + "|"
            print(choiceLine.format(choice))
            number += 1
        print(' ╚═══╩════════════════╧')

        # Option select and check
        waitforinput = input(' Choose Selection: ')

        if waitforinput == '1':
            workingOverview = hunt.huntFunction(charName, charLvl, charExp, charMun, charAtk, charDef, charSpe)
            saveload.saveOver(fileLocationUser, workingOverview[0], workingOverview[1], workingOverview[2], \
                              workingOverview[3], workingOverview[4], workingOverview[5], workingOverview[6])

        elif waitforinput == '2':
            workingOverview = levelup.levelup(charName, charLvl, charExp, charMun, charAtk, charDef, charSpe)
            saveload.saveOver(fileLocationUser, workingOverview[0], workingOverview[1], workingOverview[2], \
                              workingOverview[3], workingOverview[4], workingOverview[5], workingOverview[6])

        elif waitforinput == '3':
            workingOverview = shop.specialShop(charName, charLvl, charExp, charMun, charAtk, charDef, charSpe)
            saveload.saveOver(fileLocationUser, workingOverview[0], workingOverview[1], workingOverview[2], \
                              workingOverview[3], workingOverview[4], workingOverview[5], workingOverview[6])

        elif waitforinput == '4':
            workingOverview[3] = town.townFunction(charMun)
            saveload.saveOver(fileLocationUser, workingOverview[0], workingOverview[1], workingOverview[2], \
                              workingOverview[3], workingOverview[4], workingOverview[5], workingOverview[6])

        elif waitforinput == '5':
            stats.showStats()

        elif waitforinput == '6':
            saveload.saveOver(fileLocationUser, workingOverview[0], workingOverview[1], workingOverview[2], \
                              workingOverview[3], workingOverview[4], workingOverview[5], workingOverview[6])
            confirm = input(' Continue playing? (Y or N)')
            if confirm.upper() == 'N':
                os._exit()
            else:
                workingOverview = saveload.loadOver(fileLocationUser, charName, charLvl, charExp, charMun, charAtk,
                                                        charDef, charSpe)
        else:
            print('Invalid Choice.')
            time.sleep(1)

main()
